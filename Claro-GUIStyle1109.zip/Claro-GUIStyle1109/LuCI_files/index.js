function HolderStatusFolder(){
	$(".holder-status li label").each(function(i, Obj){
		Obj.onclick = function(){
			if(typeof $("[name=controler-status]:checked").attr("id") == "undefined")
			{
				return;
			}
			else
			{
				if($("[name=controler-status]:checked").attr("id") == $(Obj).attr("for"))
				{
					setTimeout(function(){
						$("[name=controler-status]:checked")[0].checked = false;
					}, 100);
				}
			}
		};
	});
}
function UpdateHeaderStatus(info)
{
	var ifc=info.wan;
	var ifc6 = info.wan6;
	var onst = document.getElementById('st_UP');
	var downst = document.getElementById('st_DOWN');
	var v4st=false;
	var v6st=false;
	if (ifc && ifc.ifname && ifc.proto != 'none' && ifc.ipaddr )
		{
		v4st=true;
		document.getElementById("WANIPv4").innerHTML  = ifc.ipaddr;
		document.getElementById("WANStatusv4").className = "success";
		}
	else
		{
		v4st=false;
		document.getElementById("WANIPv4").innerHTML  = "";
		document.getElementById("WANStatusv4").className = "error";
		}
	if (ifc6 && ifc6.ifname && ifc6.proto != 'none' && ifc6.ip6addr )
		{
		v6st = true;
		document.getElementById("WANStatusv6").className = "success";
		var v6add=ifc6.ip6addr.split("/",1);
		document.getElementById("WANIPv6").innerHTML = v6add;
		}
	else
		{
		v6st=false;
		document.getElementById("WANStatusv6").className = "error";
		document.getElementById("WANIPv6").innerHTML = "";
		}
	
	if ( v4st || v6st )
		{
		onst.style.display='block';
		downst.style.display='none';
		}
	else{
		onst.style.display='none';
		downst.style.display='block';
		}
	var wifi_exists=false;
	
FOREACH1:
	for (var didx = 0; didx < info.wifinets.length; didx++)
		{
		var dev = info.wifinets[didx];
		for (var nidx = 0; nidx < dev.networks.length; nidx++)
		{
			var net = dev.networks[nidx];
			var is_assoc = (net.bssid != '00:00:00:00:00:00' && net.channel && !net.disabled);
			if(is_assoc)
			{
				wifi_exists=true;
				break FOREACH1;
			}
		}
	}
	
	var wifiup = document.getElementById('WiFiStatusUp');
	var wifidown = document.getElementById('WiFiStatusDown');
	if (wifi_exists)
	{
		wifiup.style.display='block';
		wifidown.style.display='none';
	}
	else
	{
		wifiup.style.display='none';
		wifidown.style.display='block';
	}

}
